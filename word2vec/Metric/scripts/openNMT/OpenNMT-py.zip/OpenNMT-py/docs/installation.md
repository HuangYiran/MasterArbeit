## Standard

1\. [Install PyTorch](http://pytorch.org/)

2\. Clone the OpenNMT-py repository:

```bash
git clone https://github.com/OpenNMT/OpenNMT-py
cd OpenNMT-py
```

And you are ready to go! Take a look at the [quickstart](quickstart.md) to familiarize yourself with the main training workflow.

