from onmt.modules.GlobalAttention import GlobalAttention
from onmt.modules.ImageEncoder import ImageEncoder

# For flake8 compatibility.
__all__ = [GlobalAttention, ImageEncoder]
