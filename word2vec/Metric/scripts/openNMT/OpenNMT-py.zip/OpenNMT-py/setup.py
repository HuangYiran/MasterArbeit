#!/usr/bin/env python

from distutils.core import setup

setup(name='OpenNMT',
      version='0.1',
      description='OpenNMT',
      packages=['onmt', 'onmt.modules'])
