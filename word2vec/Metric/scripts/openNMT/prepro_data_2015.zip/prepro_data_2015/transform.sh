#!/bin/bash

mv preproextracted_data_2015_data_ref.bpe.noUndo.de data_source

mv preproextracted_data_2015_data_ref.bpe.noUndo.en data_ref
mv preproextracted_data_2015_data_s1.bpe.noUndo.en data_s1
mv preproextracted_data_2015_data_s2.bpe.noUndo.en data_s2

rm preproextracted_data_2015_data_s1.bpe.noUndo.de
rm preproextracted_data_2015_data_s2.bpe.noUndo.de
